"""Generate deterministic, synthetic validation fixtures for Figures 4-6.

These records reproduce the *illustrative* values visible in the manuscript.
They are not raw ESA-ADB or OPSSAT-AD measurements.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)


def write_csv(name, fieldnames, rows):
    path = DATA / name
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(path.relative_to(ROOT))


dashboard = [
    {"group":"performance","metric":"end_to_end_latency","value":24.8,"unit":"ms/window","criterion":"<=","limit":26.0,"status":"PASS"},
    {"group":"performance","metric":"sustained_throughput","value":40.3,"unit":"windows/s","criterion":">=","limit":38.0,"status":"PASS"},
    {"group":"functional","metric":"fpga_software_agreement","value":99.4,"unit":"percent","criterion":">=","limit":99.0,"status":"PASS"},
    {"group":"resource","metric":"LUT_utilization","value":41.2,"unit":"percent","criterion":"<=","limit":70.0,"status":"PASS"},
    {"group":"resource","metric":"FF_utilization","value":30.3,"unit":"percent","criterion":"<=","limit":70.0,"status":"PASS"},
    {"group":"resource","metric":"BRAM_utilization","value":52.9,"unit":"percent","criterion":"<=","limit":70.0,"status":"PASS"},
    {"group":"resource","metric":"DSP_utilization","value":45.9,"unit":"percent","criterion":"<=","limit":70.0,"status":"PASS"},
    {"group":"timing","metric":"worst_negative_slack","value":0.42,"unit":"ns","criterion":">=","limit":0.0,"status":"PASS"},
    {"group":"power","metric":"estimated_board_power","value":8.7,"unit":"W","criterion":"<=","limit":10.0,"status":"PASS"},
    {"group":"numerical","metric":"anomaly_score_MAE","value":0.007,"unit":"score","criterion":"<=","limit":0.01,"status":"PASS"},
    {"group":"functional","metric":"subsystem_localization_agreement","value":98.6,"unit":"percent","criterion":">=","limit":98.0,"status":"PASS"},
    {"group":"recovery","metric":"watchdog_recovery_time","value":63.0,"unit":"ms","criterion":"<=","limit":100.0,"status":"PASS"},
]
write_csv("figure4_dashboard_metrics.csv", dashboard[0].keys(), dashboard)

checks = [
    ("DMA transfers completed", 1),
    ("No AXI protocol errors", 1),
    ("No input/output overflow in nominal run", 1),
    ("Threshold logic verified", 1),
    ("Interrupt timing verified", 1),
    ("Corrupt updates rejected", 1),
    ("Watchdog recovery verified", 1),
]
write_csv(
    "figure4_validation_checks.csv",
    ["check", "passed"],
    [{"check": name, "passed": passed} for name, passed in checks],
)

# Down-sampled trace for display and functional checks; the physical clock is 150 MHz.
wave = []
for i in range(321):
    t = round(i * 0.1, 1)
    dma = 1 if 2.0 <= t < 8.0 else 0
    busy = 1 if 2.6 <= t < 24.8 else 0
    if t < 3.0:
        score_q8 = 0
    elif t < 4.0:
        score_q8 = round(215 * (t - 3.0))
    elif t <= 24.8:
        score_q8 = 215
    else:
        score_q8 = 0
    fault = 1 if t >= 24.8 else 0
    output_valid = 1 if 24.8 <= t < 26.0 else 0
    irq = 1 if 25.2 <= t < 26.8 else 0
    subsystem = 3 if 24.8 <= t < 28.0 else 0
    wave.append({
        "time_ms": t,
        "clock_frequency_mhz": 150,
        "dma_tvalid": dma,
        "accel_busy": busy,
        "anomaly_score_q8": score_q8,
        "anomaly_score": round(score_q8 / 256.0, 6),
        "fault_flag": fault,
        "subsystem_id": subsystem,
        "subsystem_name": "THERMAL" if subsystem == 3 else "NONE",
        "output_valid": output_valid,
        "irq": irq,
        "error_status_hex": "0x00",
    })
write_csv("figure5_ila_waveform.csv", wave[0].keys(), wave)

fault_cases = [
    {"test_case":"TC-01","scenario":"Normal","injected_condition":"Nominal telemetry within operating limits","expected_output":"fault=0; error=0; no subsystem alarm","observed_score":0.124,"observed_fault_flag":0,"observed_subsystem_id":0,"observed_subsystem":"NONE","observed_latency_ms":24.7,"error_status_hex":"0x00","recovery_ms":"","status":"PASS"},
    {"test_case":"TC-02","scenario":"Thermal fault","injected_condition":"Temperature ramp +18 C above baseline","expected_output":"fault=1; ID=THERMAL; score above threshold","observed_score":0.840,"observed_fault_flag":1,"observed_subsystem_id":3,"observed_subsystem":"THERMAL","observed_latency_ms":24.8,"error_status_hex":"0x00","recovery_ms":"","status":"PASS"},
    {"test_case":"TC-03","scenario":"Replay attack","injected_condition":"Repeated timestamp and telemetry window","expected_output":"reject update; integrity_error=1","observed_score":"","observed_fault_flag":0,"observed_subsystem_id":0,"observed_subsystem":"NONE","observed_latency_ms":5.1,"error_status_hex":"0x08","recovery_ms":"","status":"PASS"},
    {"test_case":"TC-04","scenario":"Corrupt model","injected_condition":"NVM model hash mismatch","expected_output":"block inference; model_error=1","observed_score":"","observed_fault_flag":0,"observed_subsystem_id":0,"observed_subsystem":"NONE","observed_latency_ms":3.4,"error_status_hex":"0x10","recovery_ms":"","status":"PASS"},
    {"test_case":"TC-05","scenario":"DMA overflow","injected_condition":"Input faster than buffer service rate","expected_output":"back-pressure active; no data corruption","observed_score":"","observed_fault_flag":0,"observed_subsystem_id":0,"observed_subsystem":"NONE","observed_latency_ms":7.2,"error_status_hex":"0x20","recovery_ms":"","status":"PASS"},
    {"test_case":"TC-06","scenario":"Timeout","injected_condition":"Accelerator done signal suppressed","expected_output":"watchdog reset; recovery <=100 ms","observed_score":"","observed_fault_flag":0,"observed_subsystem_id":0,"observed_subsystem":"NONE","observed_latency_ms":100.0,"error_status_hex":"0x04","recovery_ms":63,"status":"PASS"},
]
write_csv("figure6_fault_injection_results.csv", fault_cases[0].keys(), fault_cases)

# Compact synthetic telemetry windows for unit/integration tests.
fixtures = []
for case in fault_cases:
    for sample in range(128):
        base_temp = 22.0 + 0.15 * math.sin(sample / 9)
        temp = base_temp
        timestamp = sample * 10
        packet_seq = sample
        model_hash_valid = 1
        dma_ready = 1
        accel_done = 1
        if case["scenario"] == "Thermal fault":
            temp += 18.0 * max(0, sample - 31) / 96.0
        elif case["scenario"] == "Replay attack" and sample >= 64:
            timestamp = (sample - 64) * 10
            packet_seq = sample - 64
        elif case["scenario"] == "Corrupt model":
            model_hash_valid = 0
        elif case["scenario"] == "DMA overflow" and 40 <= sample < 72:
            dma_ready = 0
        elif case["scenario"] == "Timeout":
            accel_done = 0
        fixtures.append({
            "test_case": case["test_case"],
            "scenario": case["scenario"],
            "sample_index": sample,
            "timestamp_ms": timestamp,
            "temperature_c": round(temp, 4),
            "bus_voltage_v": round(28.0 + 0.08 * math.sin(sample / 13), 4),
            "bus_current_a": round(2.4 + 0.03 * math.cos(sample / 7), 4),
            "attitude_error_deg": round(0.12 + 0.01 * math.sin(sample / 11), 4),
            "packet_seq": packet_seq,
            "model_hash_valid": model_hash_valid,
            "dma_ready": dma_ready,
            "accel_done": accel_done,
            "expected_fault_flag": case["observed_fault_flag"],
            "expected_error_status_hex": case["error_status_hex"],
        })
write_csv("synthetic_telemetry_windows.csv", fixtures[0].keys(), fixtures)
