"""Validate fixture files and recreate Figures 4, 5, and 6."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)


def criterion_pass(value, op, limit):
    return value <= limit if op == "<=" else value >= limit


metrics = pd.read_csv(DATA / "figure4_dashboard_metrics.csv")
metrics["computed_pass"] = metrics.apply(
    lambda r: criterion_pass(r["value"], r["criterion"], r["limit"]), axis=1
)
checks = pd.read_csv(DATA / "figure4_validation_checks.csv")
fig6 = pd.read_csv(DATA / "figure6_fault_injection_results.csv")

report = {
    "figure4_all_metrics_pass": bool(metrics["computed_pass"].all()),
    "figure4_all_checks_pass": bool((checks["passed"] == 1).all()),
    "figure6_all_test_cases_pass": bool((fig6["status"] == "PASS").all()),
    "fixture_only": True,
    "warning": "Illustrative synthetic fixtures; replace with exported hardware measurements for publication claims.",
}
(OUT / "validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

# Figure 4: compact dashboard.
fig = plt.figure(figsize=(12, 6.8), facecolor="#f5f7fa")
gs = fig.add_gridspec(3, 4, hspace=0.55, wspace=0.45)
for i, (label, val, target) in enumerate([
    ("End-to-end latency", 24.8, "Target <= 26 ms"),
    ("Throughput", 40.3, "Target >= 38 win/s"),
    ("FPGA-SW agreement", 99.4, "Target >= 99%"),
]):
    ax = fig.add_subplot(gs[0, i]); ax.axis("off")
    ax.text(0.5, 0.78, label, ha="center", fontsize=10, color="#36536b")
    suffix = " ms" if i == 0 else (" win/s" if i == 1 else "%")
    ax.text(0.5, 0.42, f"{val}{suffix}", ha="center", fontsize=21, weight="bold", color="#16843f")
    ax.text(0.5, 0.12, target + " - PASS", ha="center", fontsize=8, color="#536273")
ax = fig.add_subplot(gs[1:, :3])
resources = metrics[metrics.group == "resource"]
ax.barh(resources.metric.str.replace("_utilization", ""), resources.value,
        color=["#2f80c0", "#25a45a", "#8257d6", "#e6a019"])
ax.set_xlim(0, 70); ax.set_xlabel("Utilization (%)"); ax.set_title("Post-implementation resource utilization")
for y, v in enumerate(resources.value): ax.text(v + 1, y, f"{v:.1f}%", va="center", fontsize=9)
ax = fig.add_subplot(gs[:, 3]); ax.axis("off")
ax.text(0.5, 0.88, "PASS", ha="center", va="center", fontsize=22, weight="bold", color="white",
        bbox=dict(boxstyle="circle,pad=0.75", facecolor="#16843f", edgecolor="none"))
ax.text(0.05, 0.68, "Validation status", weight="bold", fontsize=12, color="#27465d")
for i, check in enumerate(checks.check): ax.text(0.05, 0.61-i*0.07, "✓ " + check, fontsize=8.4)
fig.suptitle("FPGA Hardware-Validation Dashboard", fontsize=16, weight="bold", color="#173a52")
fig.savefig(OUT / "figure4_recreated.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# Figure 5: stacked ILA-style traces.
wave = pd.read_csv(DATA / "figure5_ila_waveform.csv")
signals = ["dma_tvalid", "accel_busy", "anomaly_score", "fault_flag", "subsystem_id", "output_valid", "irq"]
fig, axes = plt.subplots(len(signals), 1, figsize=(12, 8), sharex=True, facecolor="#142231")
for ax, sig in zip(axes, signals):
    ax.set_facecolor("#142231")
    ax.step(wave.time_ms, wave[sig], where="post", color="#55dfca" if sig != "anomaly_score" else "#f0c44c", lw=1.6)
    ax.set_ylabel(sig, rotation=0, ha="right", va="center", color="#dce6ef", fontsize=8, labelpad=38)
    ax.grid(color="#304354", alpha=.6); ax.tick_params(colors="#b8c6d1", labelsize=7)
    for spine in ax.spines.values(): spine.set_visible(False)
for ax in axes: ax.axvline(24.8, color="#ffd21f", ls="--", lw=1)
axes[-1].set_xlabel("Time (ms)", color="#dce6ef")
fig.suptitle("Integrated Logic Analyzer (ILA) - Recreated Trace", color="white", weight="bold")
fig.savefig(OUT / "figure5_recreated.png", dpi=200, bbox_inches="tight", facecolor=fig.get_facecolor()); plt.close(fig)

# Figure 6: fault-injection result table.
display = fig6[["test_case", "scenario", "injected_condition", "expected_output", "error_status_hex", "status"]].copy()
fig, ax = plt.subplots(figsize=(15, 6.5)); ax.axis("off")
table = ax.table(cellText=display.values, colLabels=display.columns, loc="center", cellLoc="left",
                 colWidths=[.08,.12,.24,.30,.12,.10])
table.auto_set_font_size(False); table.set_fontsize(8.2); table.scale(1, 2.1)
for (row, col), cell in table.get_celld().items():
    cell.set_edgecolor("#b9c7d3")
    if row == 0:
        cell.set_facecolor("#dce9f3"); cell.set_text_props(weight="bold", color="#173a52")
    elif col == 5:
        cell.set_facecolor("#16843f"); cell.set_text_props(color="white", weight="bold", ha="center")
ax.set_title("Illustrative Fault-Injection Validation Results", fontsize=15, weight="bold", pad=18)
fig.savefig(OUT / "figure6_recreated.png", dpi=200, bbox_inches="tight"); plt.close(fig)

if not all([report["figure4_all_metrics_pass"], report["figure4_all_checks_pass"], report["figure6_all_test_cases_pass"]]):
    raise SystemExit("Validation failed; inspect outputs/validation_report.json")
print(json.dumps(report, indent=2))

