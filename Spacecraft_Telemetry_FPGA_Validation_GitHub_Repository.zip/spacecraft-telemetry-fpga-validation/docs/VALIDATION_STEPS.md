# Sample Validation Steps

These steps validate the workflow represented by Figures 4, 5, and 6. The bundled data are deterministic synthetic fixtures. Use the same schema with exported software and FPGA measurements for publishable results.

## 1. Prepare the environment

```bash
git clone <YOUR-REPOSITORY-URL>
cd spacecraft-telemetry-fpga-validation
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 2. Run the complete sample validation

```bash
python run_all.py
python -m unittest discover -s tests -v
```

Expected result: all four unit tests pass, `outputs/validation_report.json` reports `true` for all acceptance groups, and three recreated PNG figures are produced.

## 3. Validate Figure 4: dashboard measurements

1. Open `data/figure4_dashboard_metrics.csv`.
2. Check each value using its `criterion` and `limit` columns.
3. Confirm:
   - latency is at most 26 ms per window;
   - throughput is at least 38 windows/s;
   - FPGA/software decision agreement is at least 99%;
   - LUT, FF, BRAM, and DSP utilization are each at most 70%;
   - worst negative slack is non-negative;
   - board power is at most 10 W;
   - anomaly-score MAE is at most 0.01;
   - subsystem-localization agreement is at least 98%;
   - watchdog recovery is at most 100 ms.
4. Confirm every item in `figure4_validation_checks.csv` equals `1`.
5. Run `python validate_and_plot.py` and inspect `outputs/figure4_recreated.png`.

### Replacing Figure 4 with measured values

- Export utilization and WNS from the Vivado implementation/timing reports.
- Record power from the board monitor or a documented Vivado estimate.
- Measure DMA-start to `output_valid` latency over repeated windows.
- Derive throughput from completed windows divided by elapsed time.
- Compare FPGA outputs with the quantized software golden reference.
- Replace CSV values without changing column names, then rerun validation.

## 4. Validate Figure 5: ILA waveform

1. Program the ZCU104 with the identified bitstream.
2. Configure ILA probes for `dma_tvalid`, `accel_busy`, `anomaly_score`, `fault_flag`, `subsystem_id`, `output_valid`, `irq`, and `error_status`.
3. Trigger on the rising edge of `output_valid` or `fault_flag`.
4. Replay a fixed thermal-fault telemetry window through AXI DMA.
5. Export the capture as CSV from Vivado.
6. Map the exported columns to `data/figure5_ila_waveform.csv`.
7. Verify the expected ordering:
   - DMA input becomes valid;
   - the accelerator becomes busy;
   - the anomaly score is accumulated;
   - inference completes at approximately 24.8 ms in the sample fixture;
   - `fault_flag=1` and `subsystem_id=3` identify a thermal fault;
   - `output_valid` and `irq` are asserted;
   - `error_status=0x00` for this test.
8. For the sample Q8 score, confirm `0x00D7 = 215/256 = 0.83984375`.

## 5. Validate Figure 6: fault injection

Run each case independently and save a separate raw log:

| Test | Injection | Required response |
|---|---|---|
| TC-01 | Nominal telemetry | No fault, no subsystem alarm, `0x00`. |
| TC-02 | Temperature ramp of +18 C | Fault asserted, thermal ID, score above threshold. |
| TC-03 | Repeated timestamp and telemetry window | Packet/update rejected, `0x08`. |
| TC-04 | Model-hash mismatch | Inference blocked, verified model retained, `0x10`. |
| TC-05 | Input faster than DMA buffer service | Back-pressure asserted, no silent corruption, `0x20`. |
| TC-06 | Suppressed accelerator-done signal | Watchdog reset and recovery within 100 ms, `0x04`. |

Enter measured results in `data/figure6_fault_injection_results.csv`, retain failed cases as `FAIL`, and rerun `python validate_and_plot.py`.

## 6. Dataset-to-FPGA validation procedure

1. Download ESA-ADB or OPSSAT-AD from the links in `README.md`.
2. Record the dataset version and SHA-256 checksums.
3. Select channels and freeze train, validation, and test partitions.
4. Fit normalization parameters on training data only.
5. Produce fixed 128-sample test windows and ground-truth labels.
6. Run the quantized software model to create golden scores, flags, and subsystem IDs.
7. Replay identical fixed-point windows through the FPGA.
8. Join results by window ID and timestamp.
9. Compute score MAE, decision agreement, localization agreement, latency, and throughput.
10. Archive the model hash, bitstream hash, clock constraint, Vivado version, random seeds, and raw output files.

## 7. Publication checklist

- Replace all illustrative values with traceable exports.
- Report the number of windows and repeated hardware trials.
- Include uncertainty or variation for latency and power where appropriate.
- State the fixed-point format and anomaly threshold.
- Preserve failed tests; do not report only successful runs.
- Retain the word “illustrative” until measured records replace every fixture.

