"""One-command reproduction of the sample datasets, checks, and Figures 4-6."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def run(script: str) -> None:
    env = os.environ.copy()
    env.setdefault("MPLBACKEND", "Agg")
    env.setdefault("MPLCONFIGDIR", str(ROOT / ".matplotlib-cache"))
    subprocess.run([sys.executable, str(ROOT / script)], check=True, cwd=ROOT, env=env)


if __name__ == "__main__":
    run("generate_fixture_data.py")
    run("validate_and_plot.py")
    print("\nValidation complete. Review outputs/validation_report.json and outputs/figure*_recreated.png")

