from __future__ import annotations

import csv
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"


class ValidationFixtureTests(unittest.TestCase):
    def test_dashboard_acceptance_criteria(self):
        with (DATA / "figure4_dashboard_metrics.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 12)
        for row in rows:
            value, limit = float(row["value"]), float(row["limit"])
            passed = value <= limit if row["criterion"] == "<=" else value >= limit
            self.assertTrue(passed, row["metric"])
            self.assertEqual(row["status"], "PASS")

    def test_ila_thermal_result_at_trigger(self):
        with (DATA / "figure5_ila_waveform.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        trigger = next(row for row in rows if float(row["time_ms"]) == 24.8)
        self.assertEqual(trigger["fault_flag"], "1")
        self.assertEqual(trigger["subsystem_id"], "3")
        self.assertEqual(trigger["subsystem_name"], "THERMAL")
        self.assertEqual(trigger["output_valid"], "1")
        self.assertAlmostEqual(float(trigger["anomaly_score"]), 215 / 256, places=6)

    def test_fault_injection_cases(self):
        with (DATA / "figure6_fault_injection_results.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual([r["test_case"] for r in rows], [f"TC-0{i}" for i in range(1, 7)])
        self.assertTrue(all(r["status"] == "PASS" for r in rows))
        self.assertEqual(rows[1]["observed_subsystem"], "THERMAL")
        self.assertEqual(rows[2]["error_status_hex"], "0x08")
        self.assertEqual(rows[3]["error_status_hex"], "0x10")
        self.assertEqual(rows[4]["error_status_hex"], "0x20")
        self.assertLessEqual(float(rows[5]["recovery_ms"]), 100.0)

    def test_validation_report(self):
        report = json.loads((OUT / "validation_report.json").read_text(encoding="utf-8"))
        self.assertTrue(report["figure4_all_metrics_pass"])
        self.assertTrue(report["figure4_all_checks_pass"])
        self.assertTrue(report["figure6_all_test_cases_pass"])
        self.assertTrue(report["fixture_only"])


if __name__ == "__main__":
    unittest.main()

