#!/usr/bin/env python3
import argparse
from pathlib import Path

from spacecraft_fraud.config import FixedPointConfig, TelemetryConfig
from spacecraft_fraud.data import generate_synthetic_telemetry
from spacecraft_fraud.fixed_point import quantize


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="fpga/tb/input_vectors.mem")
    parser.add_argument("--samples", type=int, default=64)
    args = parser.parse_args()

    cfg = TelemetryConfig(samples=args.samples)
    fixed = FixedPointConfig()
    x, _, _, _ = generate_synthetic_telemetry(cfg)
    q = quantize(x, fixed)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w") as fp:
        for row in q:
            words = [format(int(v) & 0xFFFF, "04x") for v in row[::-1]]
            fp.write("".join(words) + "\n")
    print(f"Wrote {len(q)} vectors to {out}")


if __name__ == "__main__":
    main()

