#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

iverilog -g2012 \
  -o build_spacecraft_fault_core.out \
  fpga/rtl/lstm_gcn_fault_core.v \
  fpga/tb/tb_lstm_gcn_fault_core.v

vvp build_spacecraft_fault_core.out

