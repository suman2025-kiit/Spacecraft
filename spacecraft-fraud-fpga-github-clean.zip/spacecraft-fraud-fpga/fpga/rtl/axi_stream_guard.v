`timescale 1ns / 1ps

module axi_stream_guard #(
    parameter DATA_WIDTH = 128,
    parameter TIMEOUT_MAX = 32'd100000
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 s_axis_tvalid,
    input  wire                 s_axis_tlast,
    input  wire [DATA_WIDTH-1:0] s_axis_tdata,
    output reg                  packet_ok,
    output reg                  integrity_error,
    output reg [31:0]           timeout_counter
);

    reg [15:0] packet_words;
    reg [15:0] rolling_xor;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            packet_ok <= 1'b0;
            integrity_error <= 1'b0;
            timeout_counter <= 32'd0;
            packet_words <= 16'd0;
            rolling_xor <= 16'd0;
        end else begin
            packet_ok <= 1'b0;
            if (s_axis_tvalid) begin
                timeout_counter <= 32'd0;
                packet_words <= packet_words + 1'b1;
                rolling_xor <= rolling_xor ^ s_axis_tdata[15:0];
                if (s_axis_tlast) begin
                    packet_ok <= (packet_words != 16'd0);
                    integrity_error <= (rolling_xor == 16'd0);
                    packet_words <= 16'd0;
                    rolling_xor <= 16'd0;
                end
            end else begin
                timeout_counter <= timeout_counter + 1'b1;
                if (timeout_counter >= TIMEOUT_MAX) begin
                    integrity_error <= 1'b1;
                    packet_words <= 16'd0;
                    rolling_xor <= 16'd0;
                end
            end
        end
    end

endmodule

