`timescale 1ns / 1ps

module lstm_gcn_fault_core #(
    parameter DATA_WIDTH = 16,
    parameter FRAC_BITS = 8,
    parameter FEATURE_COUNT = 8,
    parameter SCORE_THRESHOLD = 16'd141
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         valid_in,
    input  wire [DATA_WIDTH*FEATURE_COUNT-1:0] feature_bus,
    output reg                          ready_out,
    output reg                          valid_out,
    output reg  [15:0]                  anomaly_score,
    output reg                          fault_flag,
    output reg  [1:0]                   subsystem_id,
    output reg  [15:0]                  confidence,
    output reg  [31:0]                  cycle_count
);

    integer i;
    reg [31:0] accum_power;
    reg [31:0] accum_attitude;
    reg [31:0] accum_thermal;
    reg [31:0] accum_comms;
    reg [DATA_WIDTH-1:0] f [0:FEATURE_COUNT-1];

    always @(*) begin
        for (i = 0; i < FEATURE_COUNT; i = i + 1) begin
            f[i] = feature_bus[i*DATA_WIDTH +: DATA_WIDTH];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ready_out <= 1'b1;
            valid_out <= 1'b0;
            anomaly_score <= 16'd0;
            fault_flag <= 1'b0;
            subsystem_id <= 2'd0;
            confidence <= 16'd0;
            cycle_count <= 32'd0;
            accum_power <= 32'd0;
            accum_attitude <= 32'd0;
            accum_thermal <= 32'd0;
            accum_comms <= 32'd0;
        end else begin
            valid_out <= 1'b0;
            cycle_count <= cycle_count + 1'b1;
            if (valid_in && ready_out) begin
                accum_power <= f[0] + f[6];
                accum_attitude <= f[2] + f[3] + f[7];
                accum_thermal <= f[1] + f[4];
                accum_comms <= f[5] + f[6];

                anomaly_score <= ((f[0] + f[1] + f[2] + f[3] + f[4] + f[5] + f[6] + f[7]) >> 3);
                fault_flag <= (((f[0] + f[1] + f[2] + f[3] + f[4] + f[5] + f[6] + f[7]) >> 3) >= SCORE_THRESHOLD);

                if ((f[0] + f[6]) >= (f[2] + f[3] + f[7]) &&
                    (f[0] + f[6]) >= (f[1] + f[4]) &&
                    (f[0] + f[6]) >= (f[5] + f[6])) begin
                    subsystem_id <= 2'd0;
                    confidence <= f[0] + f[6];
                end else if ((f[2] + f[3] + f[7]) >= (f[1] + f[4]) &&
                             (f[2] + f[3] + f[7]) >= (f[5] + f[6])) begin
                    subsystem_id <= 2'd1;
                    confidence <= f[2] + f[3] + f[7];
                end else if ((f[1] + f[4]) >= (f[5] + f[6])) begin
                    subsystem_id <= 2'd2;
                    confidence <= f[1] + f[4];
                end else begin
                    subsystem_id <= 2'd3;
                    confidence <= f[5] + f[6];
                end
                valid_out <= 1'b1;
            end
        end
    end

endmodule

