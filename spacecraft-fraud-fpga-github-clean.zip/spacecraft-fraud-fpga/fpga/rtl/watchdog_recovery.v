`timescale 1ns / 1ps

module watchdog_recovery #(
    parameter TIMEOUT_LIMIT = 32'd500000
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       heartbeat,
    input  wire       integrity_error,
    output reg        recovery_irq,
    output reg        soft_reset_req,
    output reg [31:0] error_status
);

    reg [31:0] watchdog_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            recovery_irq <= 1'b0;
            soft_reset_req <= 1'b0;
            error_status <= 32'd0;
            watchdog_count <= 32'd0;
        end else begin
            recovery_irq <= 1'b0;
            soft_reset_req <= 1'b0;

            if (heartbeat) begin
                watchdog_count <= 32'd0;
            end else begin
                watchdog_count <= watchdog_count + 1'b1;
            end

            if (integrity_error) begin
                recovery_irq <= 1'b1;
                soft_reset_req <= 1'b1;
                error_status <= 32'h0000_0001;
            end else if (watchdog_count >= TIMEOUT_LIMIT) begin
                recovery_irq <= 1'b1;
                soft_reset_req <= 1'b1;
                error_status <= 32'h0000_0002;
                watchdog_count <= 32'd0;
            end
        end
    end

endmodule

