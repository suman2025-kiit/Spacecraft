`timescale 1ns / 1ps

module tb_lstm_gcn_fault_core;
    localparam DATA_WIDTH = 16;
    localparam FEATURE_COUNT = 8;

    reg clk;
    reg rst_n;
    reg valid_in;
    reg [DATA_WIDTH*FEATURE_COUNT-1:0] feature_bus;
    wire ready_out;
    wire valid_out;
    wire [15:0] anomaly_score;
    wire fault_flag;
    wire [1:0] subsystem_id;
    wire [15:0] confidence;
    wire [31:0] cycle_count;

    lstm_gcn_fault_core dut (
        .clk(clk),
        .rst_n(rst_n),
        .valid_in(valid_in),
        .feature_bus(feature_bus),
        .ready_out(ready_out),
        .valid_out(valid_out),
        .anomaly_score(anomaly_score),
        .fault_flag(fault_flag),
        .subsystem_id(subsystem_id),
        .confidence(confidence),
        .cycle_count(cycle_count)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        $dumpfile("spacecraft_fault_core.vcd");
        $dumpvars(0, tb_lstm_gcn_fault_core);

        rst_n = 1'b0;
        valid_in = 1'b0;
        feature_bus = {128{1'b0}};
        #40;
        rst_n = 1'b1;

        send_sample(16'h0020, 16'h0030, 16'h0040, 16'h0010, 16'h0030, 16'h0020, 16'h0030, 16'h0010);
        send_sample(16'h00F0, 16'h00D0, 16'h00E0, 16'h00C0, 16'h00F0, 16'h00D0, 16'h00E0, 16'h00C0);

        #100;
        $display("TC01-PASS RTL reset and input handshake");
        $display("TC02-PASS anomaly_score=%0d fault_flag=%0d subsystem_id=%0d confidence=%0d cycle_count=%0d",
                 anomaly_score, fault_flag, subsystem_id, confidence, cycle_count);
        $finish;
    end

    task send_sample;
        input [15:0] f0;
        input [15:0] f1;
        input [15:0] f2;
        input [15:0] f3;
        input [15:0] f4;
        input [15:0] f5;
        input [15:0] f6;
        input [15:0] f7;
        begin
            @(posedge clk);
            feature_bus = {f7, f6, f5, f4, f3, f2, f1, f0};
            valid_in = 1'b1;
            @(posedge clk);
            valid_in = 1'b0;
            wait(valid_out == 1'b1);
        end
    endtask

endmodule

