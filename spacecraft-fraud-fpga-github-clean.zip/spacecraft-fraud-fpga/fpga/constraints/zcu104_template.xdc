## AMD-Xilinx ZCU104 template constraints.
## Update clock and I/O pins according to your board design.

create_clock -period 10.000 [get_ports clk]
set_property PACKAGE_PIN H16 [get_ports clk]
set_property IOSTANDARD LVCMOS18 [get_ports clk]

set_property PACKAGE_PIN G15 [get_ports rst_n]
set_property IOSTANDARD LVCMOS18 [get_ports rst_n]

## Use AXI DMA or AXI-stream IP integration for feature_bus in a block design.
## Direct package pins for feature_bus are intentionally not fixed here.

