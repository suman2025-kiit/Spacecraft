import time

import numpy as np

from .config import TrustConfig
from .security import verify_signature


def cosine_similarity(a, b):
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


def validate_device_update(update, reference_delta, secret, cfg: TrustConfig):
    signature = update.get("signature", "")
    payload = {k: v for k, v in update.items() if k != "signature"}
    sig_ok = verify_signature(payload, signature, secret)
    age = int(time.time()) - int(update.get("timestamp", 0))
    fresh = age <= cfg.max_staleness_s
    similarity = cosine_similarity(update["weights_delta"], reference_delta)
    reliability = float(update.get("reliability", 0.0))
    consistency = float(update.get("consistency", 0.0))
    trust = 0.40 * similarity + 0.30 * reliability + 0.30 * consistency
    accepted = (
        sig_ok
        and fresh
        and similarity >= cfg.similarity_floor
        and reliability >= cfg.reliability_floor
        and consistency >= cfg.consistency_floor
        and trust >= cfg.tau_t
    )
    return {
        "device_id": update.get("device_id", "unknown"),
        "signature_ok": sig_ok,
        "fresh": fresh,
        "similarity": similarity,
        "reliability": reliability,
        "consistency": consistency,
        "trust": trust,
        "accepted": accepted,
    }


def trust_weighted_aggregate(updates, reference_delta, secret, cfg: TrustConfig):
    accepted = []
    weights = []
    reports = []
    for update in updates:
        report = validate_device_update(update, reference_delta, secret, cfg)
        reports.append(report)
        if report["accepted"]:
            accepted.append(np.asarray(update["weights_delta"], dtype=np.float32))
            weights.append(report["trust"])
    if not accepted:
        return np.zeros_like(reference_delta, dtype=np.float32), reports
    weights = np.asarray(weights, dtype=np.float32)
    weights = weights / np.sum(weights)
    aggregate = np.sum(np.stack(accepted) * weights[:, None], axis=0)
    return aggregate, reports

