import csv
from pathlib import Path

import numpy as np

from .config import FEATURE_NAMES, TelemetryConfig


def generate_synthetic_telemetry(cfg: TelemetryConfig):
    rng = np.random.default_rng(cfg.seed)
    base = np.array([28.0, 24.0, 3200.0, 0.03, 21.0, 14.0, 1.8, 0.08])
    scale = np.array([0.8, 1.1, 90.0, 0.01, 0.9, 1.2, 0.2, 0.03])

    x = rng.normal(base, scale, size=(cfg.samples, cfg.features))
    y = np.zeros(cfg.samples, dtype=np.int32)
    subsystem = np.zeros(cfg.samples, dtype=np.int32)

    fault_count = max(1, cfg.samples // 5)
    fault_idx = rng.choice(cfg.samples, size=fault_count, replace=False)

    for idx in fault_idx:
        fault_type = int(rng.integers(0, cfg.subsystems))
        y[idx] = 1
        subsystem[idx] = fault_type
        if fault_type == 0:
            x[idx, 0] -= rng.uniform(3.0, 6.0)
            x[idx, 6] += rng.uniform(1.0, 2.0)
        elif fault_type == 1:
            x[idx, 2] += rng.uniform(600.0, 1100.0)
            x[idx, 7] += rng.uniform(0.3, 0.8)
        elif fault_type == 2:
            x[idx, 1] += rng.uniform(8.0, 18.0)
            x[idx, 4] += rng.uniform(7.0, 15.0)
        else:
            x[idx, 5] -= rng.uniform(6.0, 10.0)
            x[idx, 6] += rng.uniform(0.5, 1.2)

    mn = base - 4.0 * scale
    mx = base + 4.0 * scale
    x_norm = np.clip((x - mn) / (mx - mn), 0.0, 1.0)
    return x_norm.astype(np.float32), y, subsystem, {"min": mn, "max": mx}


def minmax_normalize(x):
    mn = x.min(axis=0)
    mx = x.max(axis=0)
    denom = np.where((mx - mn) == 0, 1.0, mx - mn)
    return (x - mn) / denom, mn, mx


def make_windows(x, y, subsystem, window):
    n = x.shape[0] - window + 1
    xw = np.zeros((n, window, x.shape[1]), dtype=np.float32)
    yw = np.zeros(n, dtype=np.int32)
    sw = np.zeros(n, dtype=np.int32)
    for i in range(n):
        xw[i] = x[i : i + window]
        yw[i] = int(np.max(y[i : i + window]))
        sw[i] = int(subsystem[i + window - 1])
    return xw, yw, sw


def load_telemetry_csv(path):
    path = Path(path)
    rows = []
    labels = []
    subsystems = []
    with path.open("r", newline="") as fp:
        reader = csv.DictReader(fp)
        for row in reader:
            rows.append([float(row[name]) for name in FEATURE_NAMES])
            labels.append(int(row.get("fault_label", 0)))
            subsystems.append(int(row.get("subsystem_id", 0)))
    x = np.asarray(rows, dtype=np.float32)
    x_norm, mn, mx = minmax_normalize(x)
    return x_norm, np.asarray(labels), np.asarray(subsystems), {"min": mn, "max": mx}
