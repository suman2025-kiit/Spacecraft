from dataclasses import dataclass


@dataclass(frozen=True)
class TelemetryConfig:
    samples: int = 512
    window: int = 8
    features: int = 8
    subsystems: int = 4
    seed: int = 42


@dataclass(frozen=True)
class FixedPointConfig:
    total_bits: int = 16
    frac_bits: int = 8
    score_threshold: float = 0.65


@dataclass(frozen=True)
class TrustConfig:
    tau_t: float = 0.70
    max_staleness_s: int = 30
    similarity_floor: float = 0.65
    reliability_floor: float = 0.70
    consistency_floor: float = 0.70


FEATURE_NAMES = [
    "power_bus_v",
    "battery_temp_c",
    "reaction_wheel_rpm",
    "imu_vibration_g",
    "thermal_plate_c",
    "comms_snr_db",
    "payload_current_a",
    "attitude_error_deg",
]

SUBSYSTEM_NAMES = {
    0: "power",
    1: "attitude",
    2: "thermal",
    3: "communication_payload",
}
