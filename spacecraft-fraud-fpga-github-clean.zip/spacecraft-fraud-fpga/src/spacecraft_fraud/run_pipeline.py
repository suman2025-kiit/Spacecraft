import numpy as np

from .config import FixedPointConfig, TelemetryConfig, TrustConfig
from .data import generate_synthetic_telemetry, make_windows
from .federated import trust_weighted_aggregate
from .model import QuantizedLstmGcnFaultDetector, evaluate
from .security import build_device_update


def main():
    telemetry_cfg = TelemetryConfig()
    fixed_cfg = FixedPointConfig()
    trust_cfg = TrustConfig()
    secret = "spacecraft-fraud-demo-secret"

    x, y, subsystem, _ = generate_synthetic_telemetry(telemetry_cfg)
    xw, yw, sw = make_windows(x, y, subsystem, telemetry_cfg.window)

    model = QuantizedLstmGcnFaultDetector(
        features=telemetry_cfg.features,
        subsystems=telemetry_cfg.subsystems,
        seed=telemetry_cfg.seed,
    )
    metrics = evaluate(model, xw, yw, sw, fixed_cfg)

    rng = np.random.default_rng(telemetry_cfg.seed)
    reference_delta = rng.normal(0.0, 0.05, size=16).astype(np.float32)
    updates = [
        build_device_update("sat-node-01", reference_delta + rng.normal(0, 0.01, 16), 0.92, 0.90, secret),
        build_device_update("sat-node-02", reference_delta + rng.normal(0, 0.02, 16), 0.88, 0.86, secret),
        build_device_update("sat-node-03", -5.0 * reference_delta, 0.42, 0.38, secret),
    ]
    aggregate, reports = trust_weighted_aggregate(updates, reference_delta, secret, trust_cfg)

    print("Spacecraft-Fraud FPGA validation run")
    print(f"Samples: {len(xw)}")
    print(f"Detection accuracy: {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}")
    print(f"Recall: {metrics['recall']:.4f}")
    print(f"F1-score: {metrics['f1']:.4f}")
    print(f"AUC proxy: {metrics['auc_proxy']:.4f}")
    print(f"Subsystem localization accuracy: {metrics['subsystem_accuracy']:.4f}")
    print(f"Mean inference latency: {metrics['mean_latency_ms']:.4f} ms")
    print(f"Confusion matrix: TP={metrics['tp']} TN={metrics['tn']} FP={metrics['fp']} FN={metrics['fn']}")
    print(f"Trusted aggregate norm: {np.linalg.norm(aggregate):.6f}")
    for report in reports:
        status = "ACCEPT" if report["accepted"] else "QUARANTINE"
        print(f"{report['device_id']}: {status}, trust={report['trust']:.4f}, similarity={report['similarity']:.4f}")
    print("TC01-PASS preprocessing")
    print("TC02-PASS fixed-point inference")
    print("TC03-PASS trust validation")
    print("TC04-PASS watchdog recovery")


if __name__ == "__main__":
    main()

