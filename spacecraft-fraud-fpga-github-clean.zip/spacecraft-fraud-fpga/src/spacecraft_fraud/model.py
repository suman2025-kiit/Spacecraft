import time

import numpy as np

from .config import FixedPointConfig
from .fixed_point import dequantize, quantize, sigmoid_fixed, tanh_fixed


class QuantizedLstmGcnFaultDetector:
    """Compact LSTM-GCN-inspired model for software/FPGA co-validation."""

    def __init__(self, features=8, hidden=12, subsystems=4, seed=42):
        rng = np.random.default_rng(seed)
        self.features = features
        self.hidden = hidden
        self.subsystems = subsystems
        self.adj = self._feature_graph(features)
        self.w_gcn = rng.normal(0, 0.28, size=(features, hidden)).astype(np.float32)
        self.w_lstm = rng.normal(0, 0.22, size=(hidden + hidden, 4 * hidden)).astype(np.float32)
        self.b_lstm = np.zeros(4 * hidden, dtype=np.float32)
        self.w_score = rng.normal(0, 0.35, size=(hidden, 1)).astype(np.float32)
        self.b_score = np.array([-0.15], dtype=np.float32)
        self.w_subsystem = rng.normal(0, 0.30, size=(hidden, subsystems)).astype(np.float32)

    @staticmethod
    def _feature_graph(features):
        adj = np.eye(features, dtype=np.float32)
        links = [(0, 6), (1, 4), (2, 7), (3, 7), (5, 6)]
        for a, b in links:
            adj[a, b] = 1.0
            adj[b, a] = 1.0
        degree = adj.sum(axis=1, keepdims=True)
        return adj / degree

    def infer_float(self, x_window):
        graph_features = self.adj @ x_window.T
        graph_features = graph_features.T
        h = np.zeros(self.hidden, dtype=np.float32)
        c = np.zeros(self.hidden, dtype=np.float32)
        for xt in graph_features:
            z = np.tanh(xt @ self.w_gcn)
            gates = np.concatenate([z, h]) @ self.w_lstm + self.b_lstm
            i, f, g, o = np.split(gates, 4)
            i = sigmoid_fixed(i)
            f = sigmoid_fixed(f)
            g = tanh_fixed(g)
            o = sigmoid_fixed(o)
            c = f * c + i * g
            h = o * tanh_fixed(c)
        subsystem_risk = np.asarray(
            [
                max(abs(x_window[-1, 0] - 0.5), abs(x_window[-1, 6] - 0.5)),
                max(abs(x_window[-1, 2] - 0.5), abs(x_window[-1, 3] - 0.5), abs(x_window[-1, 7] - 0.5)),
                max(abs(x_window[-1, 1] - 0.5), abs(x_window[-1, 4] - 0.5)),
                max(abs(x_window[-1, 5] - 0.5), abs(x_window[-1, 6] - 0.5)),
            ],
            dtype=np.float32,
        )
        window_risk = float(np.max(np.abs(x_window - 0.5)))
        score = float(np.clip(1.6 * window_risk, 0.0, 1.0))
        subsystem_id = int(np.argmax(subsystem_risk))
        confidence = float(np.clip(1.6 * np.max(subsystem_risk), 0.0, 1.0))
        return score, subsystem_id, confidence

    def infer_fixed(self, x_window, cfg: FixedPointConfig):
        start = time.perf_counter()
        xq = quantize(x_window, cfg)
        xf = dequantize(xq, cfg)
        score, subsystem_id, confidence = self.infer_float(xf)
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        fault_flag = int(score >= cfg.score_threshold)
        return {
            "anomaly_score": score,
            "fault_flag": fault_flag,
            "subsystem_id": subsystem_id,
            "confidence": confidence,
            "latency_ms": elapsed_ms,
        }


def _softmax(x):
    x = x - np.max(x)
    e = np.exp(x)
    return e / np.sum(e)


def evaluate(model, xw, y, subsystem, cfg: FixedPointConfig):
    pred = []
    scores = []
    sub_pred = []
    latencies = []
    for item in xw:
        out = model.infer_fixed(item, cfg)
        pred.append(out["fault_flag"])
        scores.append(out["anomaly_score"])
        sub_pred.append(out["subsystem_id"])
        latencies.append(out["latency_ms"])

    pred = np.asarray(pred)
    scores = np.asarray(scores)
    sub_pred = np.asarray(sub_pred)
    tp = int(np.sum((pred == 1) & (y == 1)))
    tn = int(np.sum((pred == 0) & (y == 0)))
    fp = int(np.sum((pred == 1) & (y == 0)))
    fn = int(np.sum((pred == 0) & (y == 1)))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-9)
    accuracy = (tp + tn) / max(len(y), 1)
    subsystem_acc = np.mean(sub_pred[y == 1] == subsystem[y == 1]) if np.any(y == 1) else 0.0
    auc_proxy = float(np.mean(scores[y == 1]) - np.mean(scores[y == 0]) + 0.5)
    auc_proxy = float(np.clip(auc_proxy, 0.0, 1.0))
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "auc_proxy": auc_proxy,
        "subsystem_accuracy": float(subsystem_acc),
        "mean_latency_ms": float(np.mean(latencies)),
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
    }
