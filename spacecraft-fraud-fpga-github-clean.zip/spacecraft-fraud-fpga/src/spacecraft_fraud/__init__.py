"""Spacecraft-Fraud FPGA validation package."""

__version__ = "1.0.0"

