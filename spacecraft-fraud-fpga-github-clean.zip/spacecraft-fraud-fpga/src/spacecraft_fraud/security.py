import hashlib
import hmac
import json
import time


def canonical_json(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_hex(payload):
    if isinstance(payload, bytes):
        data = payload
    else:
        data = canonical_json(payload)
    return hashlib.sha256(data).hexdigest()


def sign_update(payload, secret):
    return hmac.new(secret.encode("utf-8"), canonical_json(payload), hashlib.sha256).hexdigest()


def verify_signature(payload, signature, secret):
    expected = sign_update(payload, secret)
    return hmac.compare_digest(expected, signature)


def build_device_update(device_id, weights_delta, reliability, consistency, secret):
    payload = {
        "device_id": device_id,
        "weights_delta": [float(x) for x in weights_delta],
        "reliability": float(reliability),
        "consistency": float(consistency),
        "timestamp": int(time.time()),
    }
    payload["hash"] = sha256_hex(payload)
    signature_payload = dict(payload)
    payload["signature"] = sign_update(signature_payload, secret)
    return payload

