import numpy as np

from .config import FixedPointConfig


def quantize(x, cfg: FixedPointConfig):
    scale = 1 << cfg.frac_bits
    qmin = -(1 << (cfg.total_bits - 1))
    qmax = (1 << (cfg.total_bits - 1)) - 1
    return np.clip(np.round(np.asarray(x) * scale), qmin, qmax).astype(np.int16)


def dequantize(q, cfg: FixedPointConfig):
    return np.asarray(q, dtype=np.float32) / float(1 << cfg.frac_bits)


def sigmoid_fixed(x):
    x = np.clip(x, -8.0, 8.0)
    return 1.0 / (1.0 + np.exp(-x))


def tanh_fixed(x):
    return np.tanh(np.clip(x, -4.0, 4.0))

